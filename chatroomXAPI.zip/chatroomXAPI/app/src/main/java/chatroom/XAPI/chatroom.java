package chatroom.XAPI;

import xapi.xapiServer;
import java.util.*;
import PrinterAnimation.PrinterAnimation;
public class chatroom {

    public static void main(String[] args) {

		String nameChat = ""; //Enter chatroom name in chatrooms #LeoxDev
		String username = ""; //Enter username account in xapi #LeoxDev
		String password = ""; //Enter password account in xapi #LeoxDev

		Scanner scan = new Scanner(System.in);
		PrinterAnimation p = new PrinterAnimation(10);
		p.print("hello x api user!");
		System.out.println();
		p.print("1- Create new chatroom");
		p.print("2- Login to chatroom");
		System.out.println();
		p.print("which one?");
		int select = scan.nextInt();
		p.print("");
        switch (select) {
            case 1 :
                CreateChat(nameChat , username , password);
				break;
            case 2 :
                LoginChat(nameChat , username , password);
				break;
		}
		p.print("");
	}
	public static void CreateChat(String nameChat , String username , String password){
	PrinterAnimation p = new PrinterAnimation(10);
		Scanner scan = new Scanner(System.in);
		p.print("Enter chatroom token : ");
		String token = scan.nextLine();
		p.print("");
		xapiServer server = new xapiServer(username , password);
		server.create(token , "LeoxDevChatX" , "json");
		server.edit(token , "LeoxDevChatX" , "" , "json");
		System.out.println(server.getData(token , "json"));
		p.print("start!");
		while(true){
			String input = scan.nextLine();
			server.edit(token , "LeoxDevChatX" , server.getData(token , "json") + "< " + nameChat + " : " + input + " >" , "json");
		}
	}
	public static void LoginChat(String nameChat , String username , String password){
	PrinterAnimation p = new PrinterAnimation(10);
		Scanner scan = new Scanner(System.in);
		p.print("Enter chatroom token : ");
		String token = scan.nextLine();
		p.print("");
		xapiServer server = new xapiServer(username , password);
		System.out.println(server.getData(token , "json"));
		p.print("start!");
		while(true){
			String input = scan.nextLine();
			server.edit(token , "LeoxDevChatX" , server.getData(token , "json") + "< " + nameChat + " : " + input + " >" , "json");
		}
	}
}