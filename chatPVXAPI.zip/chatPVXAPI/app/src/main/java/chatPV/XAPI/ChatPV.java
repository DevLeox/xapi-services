package chatPV.XAPI;

import xapi.xapiServer;
import PrinterAnimation.PrinterAnimation;
import java.util.*;

public class ChatPV {

    public static void main(String[] args) {
        
       String nameChat = ""; //Enter chatroom name in chatrooms #LeoxDev
       String username = ""; //Enter username account in xapi #LeoxDev
       String password = ""; //Enter password account in xapi #LeoxDev
       
       xapiServer server = new xapiServer(username , password);
       PrinterAnimation p = new PrinterAnimation(10);
       Scanner scan = new Scanner(System.in);
       p.print("hello x api user!");
       System.out.println();
       if(!server.isExists(nameChat , "json"))
           server.create(nameChat , "LeoxDevChatpvX" , "json");
       System.out.println(server.getData(nameChat , "json"));
       p.print("start!");
       p.print("");
       p.print("Enter the ID of the user you want to send message to : ");
       String inputID = scan.nextLine();
       p.print("");
       String inputData = scan.nextLine();
       server.edit(inputID , "LeoxDevChatpvX" , server.getData(inputID , "json") + "< " + nameChat + " : " + inputData + " >" , "json");
    }
}